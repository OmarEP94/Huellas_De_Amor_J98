package com.certus.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjemploJ98Application {

	public static void main(String[] args) {
		SpringApplication.run(EjemploJ98Application.class, args);
	}

}
