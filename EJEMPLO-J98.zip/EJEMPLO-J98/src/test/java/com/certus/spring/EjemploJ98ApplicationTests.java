package com.certus.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemploJ98ApplicationTests {

	@Test
	void contextLoads() {
	}

}
